import 'package:flutter/material.dart';

/// AnimatedBookmarkButton Class: Interactive Micro-Interaction Animation
/// FEATURE HIGHLIGHTS:
/// • ScaleTransition Sequence: Spring bounce animation on tap
/// • AnimatedSwitcher: Smooth icon morphing and gold fill color transition
class AnimatedBookmarkButton extends StatefulWidget {
  final bool initialIsBookmarked;
  final ValueChanged<bool>? onChanged;

  const AnimatedBookmarkButton({
    super.key,
    this.initialIsBookmarked = false,
    this.onChanged,
  });

  @override
  State<AnimatedBookmarkButton> createState() => _AnimatedBookmarkButtonState();
}

class _AnimatedBookmarkButtonState extends State<AnimatedBookmarkButton>
    with SingleTickerProviderStateMixin {
  late bool _isBookmarked;
  late AnimationController _controller;
  late Animation<double> _scaleAnimation;

  @override
  void initState() {
    super.initState();
    _isBookmarked = widget.initialIsBookmarked;

    // Animation Controller for micro-interaction bounce
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 250),
    );

    // Bounce sequence tween
    _scaleAnimation = TweenSequence<double>([
      TweenSequenceItem(tween: Tween(begin: 1.0, end: 1.35), weight: 50),
      TweenSequenceItem(tween: Tween(begin: 1.35, end: 1.0), weight: 50),
    ]).animate(
      CurvedAnimation(parent: _controller, curve: Curves.easeOut),
    );
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  void _toggleBookmark() {
    setState(() {
      _isBookmarked = !_isBookmarked;
    });
    _controller.forward(from: 0.0);
    if (widget.onChanged != null) {
      widget.onChanged!(_isBookmarked);
    }
  }

  @override
  Widget build(BuildContext context) {
    // FEATURE: Micro-Interaction Scale & Icon Transition
    return ScaleTransition(
      scale: _scaleAnimation,
      child: IconButton(
        icon: AnimatedSwitcher(
          duration: const Duration(milliseconds: 200),
          transitionBuilder: (child, animation) {
            return ScaleTransition(scale: animation, child: child);
          },
          child: Icon(
            _isBookmarked ? Icons.bookmark_rounded : Icons.bookmark_border_rounded,
            key: ValueKey<bool>(_isBookmarked),
            color: _isBookmarked ? Colors.amber.shade700 : Colors.white,
            size: 22,
          ),
        ),
        onPressed: _toggleBookmark,
        tooltip: _isBookmarked ? 'Saved to Favorites' : 'Save Spot',
      ),
    );
  }
}
