import 'dart:io';
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../models/user_response_model.dart';
import '../services/firebase_service.dart';
import '../services/image_service.dart';
import '../services/storage_service.dart';
import 'app_image.dart';

class AddResponseDialog extends StatefulWidget {
  final String reviewId;
  final String restaurantName;

  const AddResponseDialog({
    super.key,
    required this.reviewId,
    required this.restaurantName,
  });

  @override
  State<AddResponseDialog> createState() => _AddResponseDialogState();
}

class _AddResponseDialogState extends State<AddResponseDialog> {
  final _formKey = GlobalKey<FormState>();
  final FirebaseService _dbService = FirebaseService();
  final ImageService _imageService = ImageService();
  final StorageService _storageService = StorageService();

  final _commentController = TextEditingController();
  double _rating = 4.5;
  String _selectedImagePath = '';
  bool _isLoading = false;

  @override
  void dispose() {
    _commentController.dispose();
    super.dispose();
  }

  Future<void> _takePicture() async {
    try {
      final File? image = await _imageService.capturePhoto();
      if (image != null) {
        setState(() => _selectedImagePath = image.path);
      }
    } catch (e) {
      _showError('Camera Error: $e');
    }
  }

  Future<void> _pickFromGallery() async {
    try {
      final File? image = await _imageService.pickFromGallery();
      if (image != null) {
        setState(() => _selectedImagePath = image.path);
      }
    } catch (e) {
      _showError('Gallery Error: $e');
    }
  }

  void _showError(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(msg), backgroundColor: Colors.red),
    );
  }

  Future<void> _submitResponse() async {
    if (!_formKey.currentState!.validate()) return;

    setState(() => _isLoading = true);

    try {
      final user = FirebaseAuth.instance.currentUser;
      final userName = (user?.displayName != null && user!.displayName!.isNotEmpty)
          ? user.displayName!
          : (user?.email?.split('@')[0] ?? 'Foodie');

      String imageUrl = _selectedImagePath.trim();
      if (imageUrl.isNotEmpty && !imageUrl.startsWith('http') && !imageUrl.startsWith('data:')) {
        imageUrl = await _storageService.uploadImage(File(imageUrl), folder: 'responses');
      }

      final response = UserResponseModel(
        reviewId: widget.reviewId,
        userId: user?.uid ?? 'guest',
        userEmail: user?.email ?? 'anonymous@bitemark.com',
        userName: userName,
        userPhotoUrl: user?.photoURL ?? '',
        rating: _rating,
        comment: _commentController.text.trim(),
        imageUrl: imageUrl,
        date: DateTime.now().toIso8601String().split('T')[0],
      );

      await _dbService.createResponse(response);
      if (mounted) {
        Navigator.pop(context);
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Your review & photo were posted!'),
            backgroundColor: Colors.green,
          ),
        );
      }
    } catch (e) {
      _showError('Error saving response: $e');
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Dialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      insetPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 24),
      child: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Expanded(
                  child: Text(
                    'Add Review for ${widget.restaurantName}',
                    style: Theme.of(context).textTheme.titleMedium?.copyWith(
                          fontWeight: FontWeight.bold,
                        ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
                IconButton(
                  icon: const Icon(Icons.close),
                  onPressed: () => Navigator.pop(context),
                ),
              ],
            ),
            const Divider(),
            Flexible(
              child: SingleChildScrollView(
                child: Form(
                  key: _formKey,
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      const SizedBox(height: 8),
                      Text(
                        'Your Rating: ${_rating.toStringAsFixed(1)} ★',
                        style: const TextStyle(fontWeight: FontWeight.bold),
                      ),
                      Slider(
                        value: _rating,
                        min: 1.0,
                        max: 5.0,
                        divisions: 8,
                        label: _rating.toString(),
                        onChanged: (val) => setState(() => _rating = val),
                      ),
                      const SizedBox(height: 8),

                      TextFormField(
                        controller: _commentController,
                        maxLines: 3,
                        decoration: const InputDecoration(
                          labelText: 'Your Review / Experience',
                          hintText: 'How was the food and service?',
                          border: OutlineInputBorder(),
                        ),
                        validator: (val) => val == null || val.trim().isEmpty
                            ? 'Please write your review'
                            : null,
                      ),
                      const SizedBox(height: 16),

                      const Text(
                        'Attach Food Photo (Optional)',
                        style: TextStyle(fontWeight: FontWeight.bold, fontSize: 13),
                      ),
                      const SizedBox(height: 6),
                      if (_selectedImagePath.isNotEmpty)
                        ClipRRect(
                          borderRadius: BorderRadius.circular(12),
                          child: AppImage(
                            imageUrl: _selectedImagePath,
                            height: 140,
                            width: double.infinity,
                            fit: BoxFit.cover,
                          ),
                        ),
                      if (_selectedImagePath.isNotEmpty) const SizedBox(height: 8),

                      Row(
                        children: [
                          Expanded(
                            child: OutlinedButton.icon(
                              onPressed: _takePicture,
                              icon: const Icon(Icons.camera_alt, size: 18),
                              label: const Text('Camera'),
                            ),
                          ),
                          const SizedBox(width: 8),
                          Expanded(
                            child: OutlinedButton.icon(
                              onPressed: _pickFromGallery,
                              icon: const Icon(Icons.photo_library, size: 18),
                              label: const Text('Gallery'),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 20),

                      ElevatedButton(
                        onPressed: _isLoading ? null : _submitResponse,
                        style: ElevatedButton.styleFrom(
                          padding: const EdgeInsets.symmetric(vertical: 14),
                          backgroundColor: Theme.of(context).primaryColor,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12),
                          ),
                        ),
                        child: _isLoading
                            ? const SizedBox(
                                height: 20,
                                width: 20,
                                child: CircularProgressIndicator(
                                  strokeWidth: 2,
                                  color: Colors.white,
                                ),
                              )
                            : const Text(
                                'Submit Review',
                                style: TextStyle(
                                  fontSize: 16,
                                  fontWeight: FontWeight.bold,
                                  color: Colors.white,
                                ),
                              ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
