import 'dart:io';
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:geolocator/geolocator.dart';
import '../models/review_model.dart';
import '../services/firebase_service.dart';
import '../services/location_service.dart';
import '../services/image_service.dart';
import '../services/storage_service.dart';
import 'app_image.dart';

/// ReviewFormDialog Class: Scrollable Dialog Form for Creating/Editing Reviews
/// FEATURE HIGHLIGHT: Mobile Form with 4 Different Field Types (Text, Dropdown, Date Picker, Slider)
/// + Hardware Camera & Gallery Photo Pickers + Hardware GPS Location Sensor
class ReviewFormDialog extends StatefulWidget {
  final ReviewModel? existingReview;
  final VoidCallback? onSuccess;

  const ReviewFormDialog({super.key, this.existingReview, this.onSuccess});

  @override
  State<ReviewFormDialog> createState() => _ReviewFormDialogState();
}

class _ReviewFormDialogState extends State<ReviewFormDialog> {
  final _formKey = GlobalKey<FormState>();
  final FirebaseService _dbService = FirebaseService();
  final LocationService _locationService = LocationService();
  final ImageService _imageService = ImageService();
  final StorageService _storageService = StorageService();

  late TextEditingController _nameController;
  late TextEditingController _reviewController;

  String _selectedCuisine = 'Italian';
  double _rating = 4.0;
  DateTime _selectedDate = DateTime.now();
  bool _isLoading = false;
  bool _isFetchingLocation = false;

  double? _latitude;
  double? _longitude;
  bool _hasGpsTag = false;
  String _selectedImagePath = '';

  final List<String> _cuisines = [
    'Italian',
    'Mexican',
    'Japanese',
    'American',
    'Indian',
    'Vegan',
  ];

  @override
  void initState() {
    super.initState();
    _nameController = TextEditingController(
      text: widget.existingReview?.restaurantName ?? '',
    );
    _reviewController = TextEditingController(
      text: widget.existingReview?.reviewText ?? '',
    );

    if (widget.existingReview != null) {
      _selectedCuisine = widget.existingReview!.cuisine;
      if (_selectedCuisine.isNotEmpty && !_cuisines.contains(_selectedCuisine)) {
        _cuisines.add(_selectedCuisine);
      }
      _rating = widget.existingReview!.rating;
      _latitude = widget.existingReview!.latitude;
      _longitude = widget.existingReview!.longitude;
      _hasGpsTag = widget.existingReview!.hasGpsTag;
      _selectedImagePath = widget.existingReview!.imageUrl;
      if (widget.existingReview!.visitDate.isNotEmpty) {
        try {
          _selectedDate = DateTime.parse(widget.existingReview!.visitDate);
        } catch (_) {}
      }
    }
  }

  @override
  void dispose() {
    _nameController.dispose();
    _reviewController.dispose();
    super.dispose();
  }

  // FEATURE: Hardware Camera Sensor Integration
  Future<void> _takePicture() async {
    try {
      final File? image = await _imageService.capturePhoto();
      if (image != null) {
        setState(() {
          _selectedImagePath = image.path;
        });
      }
    } catch (e) {
      _showError('Camera Error: $e');
    }
  }

  // FEATURE: Gallery Image Picker
  Future<void> _pickFromGallery() async {
    try {
      final File? image = await _imageService.pickFromGallery();
      if (image != null) {
        setState(() {
          _selectedImagePath = image.path;
        });
      }
    } catch (e) {
      _showError('Gallery Error: $e');
    }
  }

  // FEATURE: Hardware GPS Sensor Integration
  Future<void> _fetchGPSLocation() async {
    setState(() => _isFetchingLocation = true);
    try {
      final Position? pos = await _locationService.getCurrentLocation();
      if (pos != null) {
        setState(() {
          _latitude = pos.latitude;
          _longitude = pos.longitude;
          _hasGpsTag = true;
        });
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text('GPS Location tagged successfully!'),
              backgroundColor: Colors.green,
            ),
          );
        }
      }
    } catch (e) {
      _showError(e.toString().replaceAll('Exception: ', ''));
    } finally {
      if (mounted) setState(() => _isFetchingLocation = false);
    }
  }

  // FEATURE: Form Component - Date Picker Dialog
  Future<void> _selectVisitDate(BuildContext context) async {
    final picked = await showDatePicker(
      context: context,
      initialDate: _selectedDate,
      firstDate: DateTime(2000),
      lastDate: DateTime.now(),
    );
    if (picked != null) {
      setState(() => _selectedDate = picked);
    }
  }

  void _showError(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(msg), backgroundColor: Colors.red),
    );
  }

  Future<void> _submitForm() async {
    if (!_formKey.currentState!.validate()) return;

    final user = FirebaseAuth.instance.currentUser;

    if (widget.existingReview != null && widget.existingReview!.userId != user?.uid) {
      _showError('You can only edit your own reviews.');
      return;
    }

    setState(() => _isLoading = true);

    try {
      String imageUrl = _selectedImagePath.trim();
      final oldUrl = widget.existingReview?.imageUrl ?? '';

      // Upload to Cloudinary if local file path
      if (imageUrl.isNotEmpty && !imageUrl.startsWith('http') && !imageUrl.startsWith('data:')) {
        imageUrl = await _storageService.uploadImage(File(imageUrl), folder: 'reviews');
      }

      final newReview = ReviewModel(
        id: widget.existingReview?.id,
        userId: user?.uid ?? 'guest',
        userEmail: user?.email ?? 'anonymous@bitemark.com',
        restaurantName: _nameController.text.trim(),
        cuisine: _selectedCuisine,
        rating: _rating,
        reviewText: _reviewController.text.trim(),
        imageUrl: imageUrl,
        visitDate: _selectedDate.toIso8601String().split('T')[0],
        latitude: _latitude ?? 0.0,
        longitude: _longitude ?? 0.0,
        hasGpsTag: _hasGpsTag,
      );

      if (widget.existingReview == null) {
        await _dbService.createReview(newReview);
      } else {
        await _dbService.updateReview(widget.existingReview!.id!, newReview);
        if (oldUrl.isNotEmpty && oldUrl != imageUrl) {
          await _storageService.deleteByUrl(oldUrl);
        }
      }

      if (mounted) {
        if (widget.onSuccess != null) {
          widget.onSuccess!();
        } else if (Navigator.canPop(context)) {
          Navigator.pop(context);
        }
      }
    } catch (e) {
      _showError('Error saving review: $e');
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final isEditing = widget.existingReview != null;

    // FEATURE: Dialog Component
    return Dialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      insetPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 24),
      child: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  isEditing ? 'Edit Review' : 'Add New Review',
                  style: Theme.of(context).textTheme.titleLarge?.copyWith(
                        fontWeight: FontWeight.bold,
                      ),
                ),
                IconButton(
                  icon: const Icon(Icons.close),
                  onPressed: () => Navigator.pop(context),
                ),
              ],
            ),
            const Divider(),
            Flexible(
              child: SingleChildScrollView(
                child: Form(
                  key: _formKey,
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      const SizedBox(height: 8),

                      // FEATURE: Form Field Type 1 - Text Input (TextFormField)
                      TextFormField(
                        controller: _nameController,
                        decoration: const InputDecoration(
                          labelText: 'Restaurant Name',
                          border: OutlineInputBorder(),
                        ),
                        validator: (val) => val == null || val.trim().isEmpty
                            ? 'Please enter a restaurant name'
                            : null,
                      ),
                      const SizedBox(height: 12),

                      // FEATURE: Form Field Type 2 - Dropdown Selector (DropdownButtonFormField)
                      DropdownButtonFormField<String>(
                        initialValue: _selectedCuisine,
                        decoration: const InputDecoration(
                          labelText: 'Cuisine',
                          border: OutlineInputBorder(),
                        ),
                        items: _cuisines
                            .map((c) => DropdownMenuItem(value: c, child: Text(c)))
                            .toList(),
                        onChanged: (val) => setState(() => _selectedCuisine = val!),
                      ),
                      const SizedBox(height: 12),

                      // FEATURE: Form Field Type 3 - Interactive Date Picker (InputDecorator + showDatePicker)
                      InkWell(
                        onTap: () => _selectVisitDate(context),
                        child: InputDecorator(
                          decoration: const InputDecoration(
                            labelText: 'Visit Date',
                            prefixIcon: Icon(Icons.calendar_today_outlined),
                            border: OutlineInputBorder(),
                          ),
                          child: Text(
                            '${_selectedDate.year}-${_selectedDate.month.toString().padLeft(2, '0')}-${_selectedDate.day.toString().padLeft(2, '0')}',
                          ),
                        ),
                      ),
                      const SizedBox(height: 12),

                      // FEATURE: Form Field Type 4 - Interactive Slider Control
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Rating: ${_rating.toStringAsFixed(1)} ★',
                            style: const TextStyle(fontWeight: FontWeight.bold),
                          ),
                          Slider(
                            value: _rating,
                            min: 1.0,
                            max: 5.0,
                            divisions: 8,
                            label: _rating.toString(),
                            onChanged: (val) => setState(() => _rating = val),
                          ),
                        ],
                      ),

                      TextFormField(
                        controller: _reviewController,
                        maxLines: 2,
                        decoration: const InputDecoration(
                          labelText: 'Review Comments',
                          border: OutlineInputBorder(),
                        ),
                        validator: (val) => val == null || val.trim().isEmpty
                            ? 'Please write a review comment'
                            : null,
                      ),
                      const SizedBox(height: 16),

                      // Dish Photo Header / Preview Box
                      const Text(
                        'Food Dish Photo',
                        style: TextStyle(fontWeight: FontWeight.bold, fontSize: 13),
                      ),
                      const SizedBox(height: 6),
                      ClipRRect(
                        borderRadius: BorderRadius.circular(12),
                        child: AppImage(
                          imageUrl: _selectedImagePath,
                          height: 150,
                          width: double.infinity,
                          fit: BoxFit.cover,
                        ),
                      ),
                      const SizedBox(height: 8),

                      // FEATURE: OutlinedButtons for Camera & Gallery Pickers
                      Row(
                        children: [
                          Expanded(
                            child: OutlinedButton.icon(
                              onPressed: _takePicture,
                              icon: const Icon(Icons.camera_alt, size: 18),
                              label: const Text('Camera', style: TextStyle(fontSize: 12)),
                            ),
                          ),
                          const SizedBox(width: 8),
                          Expanded(
                            child: OutlinedButton.icon(
                              onPressed: _pickFromGallery,
                              icon: const Icon(Icons.photo_library, size: 18),
                              label: const Text('Gallery', style: TextStyle(fontSize: 12)),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 16),

                      // FEATURE: ElevatedButton for Hardware GPS Tagging
                      ElevatedButton.icon(
                        onPressed: _isFetchingLocation ? null : _fetchGPSLocation,
                        style: ElevatedButton.styleFrom(
                          padding: const EdgeInsets.symmetric(vertical: 12),
                        ),
                        icon: _isFetchingLocation
                            ? const SizedBox(
                                height: 16,
                                width: 16,
                                child: CircularProgressIndicator(strokeWidth: 2),
                              )
                            : const Icon(Icons.my_location),
                        label: Text(
                          _latitude != null
                              ? 'GPS: ${_latitude!.toStringAsFixed(3)}, ${_longitude!.toStringAsFixed(3)}'
                              : 'Tag Current Location (GPS)',
                        ),
                      ),
                      const SizedBox(height: 16),

                      // FEATURE: Submit ElevatedButton
                      ElevatedButton(
                        onPressed: _isLoading ? null : _submitForm,
                        style: ElevatedButton.styleFrom(
                          padding: const EdgeInsets.symmetric(vertical: 14),
                          backgroundColor: Theme.of(context).primaryColor,
                        ),
                        child: _isLoading
                            ? const SizedBox(
                                height: 20,
                                width: 20,
                                child: CircularProgressIndicator(
                                  strokeWidth: 2,
                                  color: Colors.white,
                                ),
                              )
                            : Text(
                                isEditing ? 'Update Review' : 'Post Review',
                                style: const TextStyle(
                                  fontSize: 16,
                                  fontWeight: FontWeight.bold,
                                  color: Colors.white,
                                ),
                              ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
