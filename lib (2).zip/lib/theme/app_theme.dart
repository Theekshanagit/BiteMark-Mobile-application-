import 'package:flutter/material.dart';

/// AppTheme Class: Manages Material 3 Light & Dark Theme Configurations
/// FEATURE HIGHLIGHT: High-Contrast Light & Dark Mode Palettes (WCAG AAA/AA Compliant)
class AppTheme {
  // Light Theme Custom Color Palette
  static const Color primaryColor = Color(0xFF174C65);
  static const Color secondaryColor = Color(0xFF287C8E);
  static const Color accentColor = Color(0xFFFF8066); // Coral accent for buttons & badges
  static const Color backgroundColor = Color(0xFFEAF5F5);
  static const Color textColor = Color(0xFF263238);

  // Dark Theme High Contrast Palette
  static const Color darkPrimaryColor = Color(0xFF80DEEA); // Bright high-contrast cyan (> 8.5:1 ratio)
  static const Color darkSecondaryColor = Color(0xFF4DD0E1);
  static const Color darkOnButtonColor = Color(0xFF101B20); // Dark text on coral/cyan buttons (> 7:1 ratio)

  // ==========================================
  // LIGHT THEME CONFIGURATION
  // ==========================================
  static ThemeData lightTheme = ThemeData(
    useMaterial3: true,
    colorScheme: const ColorScheme.light(
      primary: primaryColor,
      secondary: secondaryColor,
      surface: backgroundColor,
      onPrimary: Colors.white,
      onSecondary: Colors.white,
      onSurface: textColor,
      onSurfaceVariant: Color(0xFF455A64),
    ),
    scaffoldBackgroundColor: backgroundColor,

    // AppBar Styling Feature
    appBarTheme: const AppBarTheme(
      centerTitle: true,
      elevation: 0,
      backgroundColor: Colors.transparent,
      iconTheme: IconThemeData(color: primaryColor),
      titleTextStyle: TextStyle(
        fontSize: 22,
        fontWeight: FontWeight.bold,
        color: primaryColor,
      ),
    ),

    // Card Component Theme Feature
    cardTheme: CardThemeData(
      color: Colors.white,
      elevation: 4,
      shadowColor: primaryColor.withValues(alpha: 0.12),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
    ),

    // Input Form Fields Theme Feature
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: Colors.white,
      contentPadding: const EdgeInsets.all(16),
      labelStyle: const TextStyle(color: secondaryColor, fontWeight: FontWeight.w600),
      hintStyle: const TextStyle(color: Colors.black38),
      prefixIconColor: secondaryColor,
      suffixIconColor: secondaryColor,
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(16),
        borderSide: BorderSide.none,
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(16),
        borderSide: BorderSide(color: secondaryColor.withValues(alpha: 0.2)),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(16),
        borderSide: const BorderSide(color: primaryColor, width: 2),
      ),
    ),

    // Chip Component Theme Feature
    chipTheme: ChipThemeData(
      backgroundColor: secondaryColor.withValues(alpha: 0.1),
      selectedColor: primaryColor,
      labelStyle: const TextStyle(color: textColor, fontWeight: FontWeight.w600),
      secondaryLabelStyle: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
    ),

    // FloatingActionButton Theme Feature
    floatingActionButtonTheme: const FloatingActionButtonThemeData(
      backgroundColor: accentColor,
      foregroundColor: darkOnButtonColor,
      elevation: 6,
    ),

    // ElevatedButton Theme Feature
    elevatedButtonTheme: ElevatedButtonThemeData(
      style: ElevatedButton.styleFrom(
        backgroundColor: primaryColor,
        foregroundColor: Colors.white,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      ),
    ),

    // Dialog Component Theme Feature
    dialogTheme: DialogThemeData(
      backgroundColor: Colors.white,
      titleTextStyle: const TextStyle(color: textColor, fontSize: 20, fontWeight: FontWeight.bold),
      contentTextStyle: const TextStyle(color: textColor, fontSize: 16),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
    ),
  );

  // ==========================================
  // DARK THEME CONFIGURATION
  // ==========================================
  static ThemeData darkTheme = ThemeData(
    useMaterial3: true,
    colorScheme: const ColorScheme.dark(
      primary: darkPrimaryColor,
      secondary: darkSecondaryColor,
      surface: Color(0xFF1E2D38),
      onPrimary: darkOnButtonColor,
      onSecondary: darkOnButtonColor,
      onSurface: Colors.white,
      onSurfaceVariant: Color(0xFFECEFF1),
    ),
    scaffoldBackgroundColor: const Color(0xFF121E24),

    textTheme: const TextTheme(
      bodyLarge: TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.w500),
      bodyMedium: TextStyle(color: Color(0xFFECEFF1), fontSize: 14, fontWeight: FontWeight.w500),
      titleLarge: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 20),
      titleMedium: TextStyle(color: Colors.white, fontWeight: FontWeight.w600, fontSize: 16),
      titleSmall: TextStyle(color: Color(0xFFCFD8DC), fontSize: 13, fontWeight: FontWeight.w500),
    ),

    appBarTheme: const AppBarTheme(
      centerTitle: true,
      elevation: 0,
      backgroundColor: Colors.transparent,
      iconTheme: IconThemeData(color: Colors.white),
      titleTextStyle: TextStyle(
        fontSize: 22,
        fontWeight: FontWeight.bold,
        color: Colors.white,
      ),
    ),

    cardTheme: CardThemeData(
      color: const Color(0xFF1E2D38),
      elevation: 6,
      shadowColor: Colors.black.withValues(alpha: 0.5),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(20),
        side: const BorderSide(color: Colors.white24, width: 1),
      ),
    ),

    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: const Color(0xFF283A46),
      contentPadding: const EdgeInsets.all(16),
      labelStyle: const TextStyle(color: Colors.white, fontWeight: FontWeight.w600),
      hintStyle: const TextStyle(color: Colors.white60),
      prefixIconColor: darkPrimaryColor,
      suffixIconColor: darkPrimaryColor,
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(16),
        borderSide: const BorderSide(color: Colors.white24),
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(16),
        borderSide: const BorderSide(color: Colors.white24),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(16),
        borderSide: const BorderSide(color: darkPrimaryColor, width: 2),
      ),
    ),

    chipTheme: ChipThemeData(
      backgroundColor: const Color(0xFF283A46),
      selectedColor: accentColor,
      labelStyle: const TextStyle(color: Colors.white, fontWeight: FontWeight.w600),
      secondaryLabelStyle: const TextStyle(color: darkOnButtonColor, fontWeight: FontWeight.bold),
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(20),
        side: const BorderSide(color: Colors.white24),
      ),
    ),

    floatingActionButtonTheme: const FloatingActionButtonThemeData(
      backgroundColor: accentColor,
      foregroundColor: darkOnButtonColor,
      elevation: 6,
    ),

    elevatedButtonTheme: ElevatedButtonThemeData(
      style: ElevatedButton.styleFrom(
        backgroundColor: darkPrimaryColor,
        foregroundColor: darkOnButtonColor,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      ),
    ),

    dialogTheme: DialogThemeData(
      backgroundColor: const Color(0xFF1E2D38),
      titleTextStyle: const TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold),
      contentTextStyle: const TextStyle(color: Color(0xFFECEFF1), fontSize: 16),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(20),
        side: const BorderSide(color: Colors.white24),
      ),
    ),

    navigationBarTheme: NavigationBarThemeData(
      backgroundColor: const Color(0xFF121E24),
      indicatorColor: accentColor.withValues(alpha: 0.35),
      labelTextStyle: WidgetStateProperty.resolveWith((states) {
        if (states.contains(WidgetState.selected)) {
          return const TextStyle(color: accentColor, fontWeight: FontWeight.bold);
        }
        return const TextStyle(color: Colors.white70);
      }),
      iconTheme: WidgetStateProperty.resolveWith((states) {
        if (states.contains(WidgetState.selected)) {
          return const IconThemeData(color: accentColor);
        }
        return const IconThemeData(color: Colors.white70);
      }),
    ),
  );
}
