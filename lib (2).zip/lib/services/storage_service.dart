import 'dart:convert';
import 'dart:io';
import 'package:http/http.dart' as http;

class StorageService {
  // Cloudinary constants (unsigned client-side upload configuration)
  static const _cloudName = 'rxqher4b';
  static const _uploadPreset = 'bitemark_unsigned';

  // Upload an image file to Cloudinary and return its HTTPS secure_url
  Future<String> uploadImage(File file, {required String folder}) async {
    if (!file.existsSync()) {
      throw Exception('Selected image file does not exist on device.');
    }

    final uri = Uri.parse('https://api.cloudinary.com/v1_1/$_cloudName/image/upload');

    final request = http.MultipartRequest('POST', uri)
      ..fields['upload_preset'] = _uploadPreset
      ..fields['folder'] = 'bitemark/$folder'
      ..files.add(await http.MultipartFile.fromPath('file', file.path));

    final streamedResponse = await request.send();
    final response = await http.Response.fromStream(streamedResponse);

    if (response.statusCode != 200) {
      try {
        final errJson = jsonDecode(response.body);
        if (errJson is Map && errJson['error'] != null && errJson['error']['message'] != null) {
          throw Exception('Cloudinary Error: ${errJson['error']['message']}');
        }
      } catch (e) {
        if (e.toString().contains('Cloudinary Error:')) rethrow;
      }
      throw Exception('Image upload failed (${response.statusCode}): ${response.body}');
    }

    final data = jsonDecode(response.body) as Map<String, dynamic>;
    final secureUrl = data['secure_url'] as String?;
    if (secureUrl == null || secureUrl.isEmpty) {
      throw Exception('Cloudinary did not return a valid secure_url');
    }

    return secureUrl;
  }

  // Upload a Base64 Data URI string to Cloudinary for legacy migration
  Future<String> uploadDataUri(String dataUri, {required String folder}) async {
    final uri = Uri.parse('https://api.cloudinary.com/v1_1/$_cloudName/image/upload');

    final response = await http.post(
      uri,
      body: {
        'upload_preset': _uploadPreset,
        'folder': 'bitemark/$folder',
        'file': dataUri,
      },
    );

    if (response.statusCode != 200) {
      try {
        final errJson = jsonDecode(response.body);
        if (errJson is Map && errJson['error'] != null && errJson['error']['message'] != null) {
          throw Exception('Cloudinary Error: ${errJson['error']['message']}');
        }
      } catch (e) {
        if (e.toString().contains('Cloudinary Error:')) rethrow;
      }
      throw Exception('Data URI upload failed (${response.statusCode}): ${response.body}');
    }

    final data = jsonDecode(response.body) as Map<String, dynamic>;
    final secureUrl = data['secure_url'] as String?;
    if (secureUrl == null || secureUrl.isEmpty) {
      throw Exception('Cloudinary did not return a valid secure_url');
    }

    return secureUrl;
  }

  // Unsigned client-side uploads cannot be deleted directly from the client without API secrets.
  // Method kept as a no-op so callers remain ready if signed deletion is enabled later.
  Future<void> deleteByUrl(String url) async {
    return;
  }
}
