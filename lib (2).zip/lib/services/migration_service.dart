import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'storage_service.dart';

class MigrationService {
  final FirebaseDatabase _db = FirebaseDatabase.instance;
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final StorageService _storageService = StorageService();

  // One-off migration function to convert user's legacy Base64 Data URIs to Cloudinary secure_urls
  Future<int> migrateMyBase64Images() async {
    final user = _auth.currentUser;
    if (user == null) return 0;
    final uid = user.uid;
    int count = 0;

    // 1. Query user's reviews with Base64 imageUrls
    final reviewsRef = _db.ref('reviews');
    final reviewsSnapshot = await reviewsRef.orderByChild('userId').equalTo(uid).get();

    if (reviewsSnapshot.exists && reviewsSnapshot.value is Map) {
      final reviewsMap = Map<dynamic, dynamic>.from(reviewsSnapshot.value as Map);
      for (final entry in reviewsMap.entries) {
        final key = entry.key.toString();
        final value = Map<dynamic, dynamic>.from(entry.value as Map);
        final imageUrl = (value['imageUrl'] ?? '').toString().trim();

        if (imageUrl.startsWith('data:image/')) {
          try {
            final secureUrl = await _storageService.uploadDataUri(imageUrl, folder: 'reviews');
            await reviewsRef.child(key).update({'imageUrl': secureUrl});
            count++;
          } catch (_) {
            // Continue migrating remaining items on individual error
          }
        }
      }
    }

    // 2. Query user's responses with Base64 imageUrls
    final responsesRef = _db.ref('responses');
    final responsesSnapshot = await responsesRef.orderByChild('userId').equalTo(uid).get();

    if (responsesSnapshot.exists && responsesSnapshot.value is Map) {
      final responsesMap = Map<dynamic, dynamic>.from(responsesSnapshot.value as Map);
      for (final entry in responsesMap.entries) {
        final key = entry.key.toString();
        final value = Map<dynamic, dynamic>.from(entry.value as Map);
        final imageUrl = (value['imageUrl'] ?? '').toString().trim();

        if (imageUrl.startsWith('data:image/')) {
          try {
            final secureUrl = await _storageService.uploadDataUri(imageUrl, folder: 'responses');
            await responsesRef.child(key).update({'imageUrl': secureUrl});
            count++;
          } catch (_) {
            // Continue migrating remaining items on individual error
          }
        }
      }
    }

    return count;
  }
}
