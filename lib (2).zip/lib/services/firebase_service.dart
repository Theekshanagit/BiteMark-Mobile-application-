import 'package:firebase_database/firebase_database.dart';
import '../models/review_model.dart';
import '../models/user_response_model.dart';
import 'storage_service.dart';

class FirebaseService {
  final DatabaseReference _dbRef = FirebaseDatabase.instance.ref('reviews');
  final DatabaseReference _responsesRef = FirebaseDatabase.instance.ref('responses');
  final StorageService _storageService = StorageService();

  // CREATE: Push a new review to Realtime Database
  Future<void> createReview(ReviewModel review) async {
    try {
      await _dbRef.push().set(review.toMap());
    } catch (e) {
      rethrow;
    }
  }

  // READ: Realtime Stream of all reviews sorted newest first
  Stream<List<ReviewModel>> getReviewsStream() {
    return _dbRef.onValue.map((event) {
      final List<ReviewModel> reviewsList = [];
      final data = event.snapshot.value;

      if (data is Map) {
        data.forEach((key, value) {
          if (value is Map) {
            final reviewMap = Map<dynamic, dynamic>.from(value);
            reviewsList.add(ReviewModel.fromMap(key.toString(), reviewMap));
          }
        });
      }
      // Sort newest first by visitDate
      reviewsList.sort((a, b) => b.visitDate.compareTo(a.visitDate));
      return reviewsList;
    });
  }

  // UPDATE: Update an existing review by ID
  Future<void> updateReview(String reviewId, ReviewModel review) async {
    try {
      await _dbRef.child(reviewId).update(review.toMap());
    } catch (e) {
      rethrow;
    }
  }

  // DELETE: Remove a review, its image file in Storage, and cascade delete associated community responses & images
  Future<void> deleteReview(ReviewModel review) async {
    try {
      if (review.id == null) return;
      final reviewId = review.id!;

      // 1. Delete review node
      await _dbRef.child(reviewId).remove();

      // 2. Cascade delete all responses linked to this reviewId
      final snapshot = await _responsesRef.get();
      if (snapshot.exists && snapshot.value is Map) {
        final data = snapshot.value as Map;
        for (final entry in data.entries) {
          if (entry.value is Map && entry.value['reviewId'] == reviewId) {
            final respMap = Map<dynamic, dynamic>.from(entry.value as Map);
            final respImageUrl = (respMap['imageUrl'] ?? '').toString();
            await _responsesRef.child(entry.key.toString()).remove();
            if (respImageUrl.isNotEmpty) {
              await _storageService.deleteByUrl(respImageUrl);
            }
          }
        }
      }

      // 3. Delete the review's main image from Storage
      if (review.imageUrl.isNotEmpty) {
        await _storageService.deleteByUrl(review.imageUrl);
      }
    } catch (e) {
      rethrow;
    }
  }

  // CREATE RESPONSE: Push a user's response/review to a spot
  Future<void> createResponse(UserResponseModel response) async {
    try {
      await _responsesRef.push().set(response.toMap());
    } catch (e) {
      rethrow;
    }
  }

  // READ RESPONSES: Stream all user responses for a specific reviewId
  Stream<List<UserResponseModel>> getResponsesStream(String reviewId) {
    return _responsesRef.onValue.map((event) {
      final List<UserResponseModel> list = [];
      final data = event.snapshot.value;

      if (data is Map) {
        data.forEach((key, value) {
          if (value is Map) {
            final map = Map<dynamic, dynamic>.from(value);
            final item = UserResponseModel.fromMap(key.toString(), map);
            if (item.reviewId == reviewId) {
              list.add(item);
            }
          }
        });
      }
      list.sort((a, b) => b.date.compareTo(a.date));
      return list;
    });
  }

  // DELETE RESPONSE: Remove a response by ID and delete its image file in Storage
  Future<void> deleteResponse(String responseId, [String? imageUrl]) async {
    try {
      await _responsesRef.child(responseId).remove();
      if (imageUrl != null && imageUrl.isNotEmpty) {
        await _storageService.deleteByUrl(imageUrl);
      }
    } catch (e) {
      rethrow;
    }
  }
}
