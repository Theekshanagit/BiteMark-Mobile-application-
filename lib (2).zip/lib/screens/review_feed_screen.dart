import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../models/review_model.dart';
import '../services/firebase_service.dart';
import '../widgets/review_form_dialog.dart';
import '../widgets/app_image.dart';
import '../widgets/custom_page_route.dart';
import '../widgets/animated_bookmark_button.dart';
import 'detail_screen.dart';
import '../theme/app_theme.dart';

/// ReviewFeedScreen Class: Main Food Review Feed Screen
/// FEATURE HIGHLIGHTS:
/// • Card Component with Hero image, rating badge, and action buttons
/// • Micro-Interaction: Animated scale-bounce bookmark button
/// • Custom Page Route Transition when navigating to DetailScreen
/// • Responsive Orientation Layout: 2-column Grid in Landscape vs 1-column List in Portrait
class ReviewFeedScreen extends StatelessWidget {
  const ReviewFeedScreen({super.key});

  // FEATURE: Card Component Builder
  Widget _buildReviewCard(BuildContext context, ReviewModel review, FirebaseService dbService) {
    final user = FirebaseAuth.instance.currentUser;
    final currentUserId = user?.uid;
    final currentUserEmail = user?.email?.toLowerCase().trim();
    final currentDisplayName = user?.displayName?.toLowerCase().trim();

    // Ownership check for editing/deleting rights
    final isOwner = (currentUserId != null && currentUserId == review.userId) ||
        (currentUserEmail != null &&
            currentUserEmail.isNotEmpty &&
            review.userEmail.toLowerCase().trim() == currentUserEmail) ||
        (currentDisplayName != null &&
            currentDisplayName.isNotEmpty &&
            (review.userEmail.toLowerCase().contains(currentDisplayName) ||
             review.userId.toLowerCase().contains(currentDisplayName)));

    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(24),
        boxShadow: [
          BoxShadow(
            color: AppTheme.primaryColor.withValues(alpha: 0.08),
            blurRadius: 15,
            offset: const Offset(0, 8),
          )
        ],
      ),
      child: Card(
        clipBehavior: Clip.antiAlias,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
            InkWell(
              onTap: () {
                // FEATURE: Custom Page Route Transition
                Navigator.push(
                  context,
                  CustomPageRoute(child: DetailScreen(review: review)),
                );
              },
              child: Stack(
                children: [
                  Hero(
                    tag: 'review-image-${review.id}',
                    child: AppImage(
                      imageUrl: review.imageUrl,
                      height: 175,
                      width: double.infinity,
                      fit: BoxFit.cover,
                    ),
                  ),
                  Positioned.fill(
                    child: Container(
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          begin: Alignment.topCenter,
                          end: Alignment.bottomCenter,
                          colors: [
                            Colors.black38,
                            Colors.transparent,
                            AppTheme.primaryColor.withValues(alpha: 0.85),
                          ],
                          stops: const [0.0, 0.4, 1.0],
                        ),
                      ),
                    ),
                  ),
                  // FEATURE: Micro-Interaction Animation (Scale-Bounce Bookmark Button)
                  Positioned(
                    top: 8,
                    left: 8,
                    child: Container(
                      decoration: const BoxDecoration(
                        color: Colors.black38,
                        shape: BoxShape.circle,
                      ),
                      child: const AnimatedBookmarkButton(),
                    ),
                  ),
                  Positioned(
                    bottom: 12,
                    left: 16,
                    right: 16,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          review.restaurantName,
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 20,
                            fontWeight: FontWeight.bold,
                            shadows: [Shadow(blurRadius: 4, color: Colors.black54)],
                          ),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                        Text(
                          '${review.cuisine} • Visited ${review.visitDate}',
                          style: const TextStyle(color: Colors.white70, fontSize: 12),
                        ),
                      ],
                    ),
                  ),
                  Positioned(
                    top: 12,
                    right: 12,
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                      decoration: BoxDecoration(
                        color: AppTheme.accentColor,
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          const Icon(Icons.star_rounded, color: AppTheme.darkOnButtonColor, size: 16),
                          const SizedBox(width: 4),
                          Text(
                            review.rating.toStringAsFixed(1),
                            style: const TextStyle(
                              color: AppTheme.darkOnButtonColor,
                              fontWeight: FontWeight.bold,
                              fontSize: 13,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(14),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    review.reviewText,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      fontSize: 14,
                      height: 1.4,
                      color: Theme.of(context).colorScheme.onSurface,
                    ),
                  ),
                  const SizedBox(height: 10),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      if (review.hasGpsTag)
                        const Row(
                          children: [
                            Icon(Icons.location_on_outlined, size: 16, color: AppTheme.secondaryColor),
                            SizedBox(width: 4),
                            Text(
                              'GPS Tagged',
                              style: TextStyle(fontSize: 12, color: AppTheme.secondaryColor),
                            ),
                          ],
                        )
                      else
                        const SizedBox.shrink(),
                      if (isOwner)
                        Row(
                          children: [
                            IconButton(
                              icon: const Icon(Icons.edit_outlined, size: 20, color: AppTheme.primaryColor),
                              onPressed: () {
                                showDialog(
                                  context: context,
                                  builder: (_) => ReviewFormDialog(existingReview: review),
                                );
                              },
                            ),
                            IconButton(
                              icon: const Icon(Icons.delete_outline, size: 20, color: Colors.redAccent),
                              onPressed: () => _confirmDelete(context, dbService, review),
                            ),
                          ],
                        ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final FirebaseService dbService = FirebaseService();
    final isLandscape = MediaQuery.of(context).orientation == Orientation.landscape;

    return Scaffold(
      appBar: AppBar(
        title: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: AppTheme.secondaryColor.withValues(alpha: 0.15),
                shape: BoxShape.circle,
              ),
              child: const Icon(Icons.restaurant, color: AppTheme.primaryColor),
            ),
            const SizedBox(width: 10),
            const Text(
              'BiteMark',
              style: TextStyle(fontWeight: FontWeight.w800),
            ),
          ],
        ),
      ),
      body: StreamBuilder<List<ReviewModel>>(
        stream: dbService.getReviewsStream(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }

          if (snapshot.hasError) {
            return Center(
              child: Text(
                'Error: ${snapshot.error}',
                style: const TextStyle(color: Colors.red),
              ),
            );
          }

          final reviews = snapshot.data ?? [];

          if (reviews.isEmpty) {
            return Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.no_meals, size: 80, color: AppTheme.secondaryColor.withValues(alpha: 0.5)),
                  const SizedBox(height: 16),
                  Text(
                    'No food reviews yet!',
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      color: Theme.of(context).colorScheme.onSurface,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    'Tap the button below to add your first spot.',
                    style: TextStyle(
                      color: Theme.of(context).colorScheme.onSurface.withValues(alpha: 0.7),
                    ),
                  ),
                ],
              ),
            );
          }

          // FEATURE: Responsive Layout - 2-column grid in Landscape vs 1-column list in Portrait
          if (isLandscape) {
            return GridView.builder(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                crossAxisSpacing: 16,
                mainAxisSpacing: 16,
                childAspectRatio: 0.72,
              ),
              itemCount: reviews.length,
              itemBuilder: (context, index) {
                return _buildReviewCard(context, reviews[index], dbService);
              },
            );
          }

          return ListView.builder(
            itemCount: reviews.length,
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            itemBuilder: (context, index) {
              return _buildReviewCard(context, reviews[index], dbService);
            },
          );
        },
      ),
      // FEATURE: FloatingActionButton Component
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () {
          showDialog(
            context: context,
            builder: (_) => const ReviewFormDialog(),
          );
        },
        backgroundColor: AppTheme.accentColor,
        foregroundColor: AppTheme.darkOnButtonColor,
        icon: const Icon(Icons.add_rounded, color: AppTheme.darkOnButtonColor, size: 26),
        label: const Text('Add Review', style: TextStyle(color: AppTheme.darkOnButtonColor, fontWeight: FontWeight.bold)),
      ),
    );
  }

  }
void _confirmDelete(BuildContext context, FirebaseService dbService, ReviewModel review) {
  showDialog(
    context: context,
    builder: (ctx) => AlertDialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      title: Text('Delete Review', style: TextStyle(color: Theme.of(context).colorScheme.onSurface)),
      content: Text('Are you sure you want to delete this review?', style: TextStyle(color: Theme.of(context).colorScheme.onSurface)),
      actions: [
        TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
        ElevatedButton(
          style: ElevatedButton.styleFrom(backgroundColor: Colors.redAccent),
          onPressed: () async {
            Navigator.pop(ctx);
            await dbService.deleteReview(review);
          },
          child: const Text('Delete', style: TextStyle(color: Colors.white)),
        ),
      ],
    ),
  );
}
}
