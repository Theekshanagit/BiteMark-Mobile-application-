import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../models/review_model.dart';
import '../models/user_response_model.dart';
import '../services/firebase_service.dart';
import '../widgets/app_image.dart';
import '../widgets/add_response_dialog.dart';
import '../theme/app_theme.dart';

class DetailScreen extends StatelessWidget {
  final ReviewModel review;

  const DetailScreen({super.key, required this.review});

  ImageProvider? _getUserAvatar(String photoUrl) {
    if (photoUrl.isEmpty) return null;
    final trimmed = photoUrl.trim();

    if (trimmed.startsWith('data:image/')) {
      try {
        final commaIndex = trimmed.indexOf(',');
        if (commaIndex != -1) {
          return MemoryImage(base64Decode(trimmed.substring(commaIndex + 1)));
        }
      } catch (_) {}
    }

    if (trimmed.startsWith('http://') || trimmed.startsWith('https://')) {
      return NetworkImage(trimmed);
    }

    final file = File(trimmed);
    if (file.existsSync()) {
      return FileImage(file);
    }
    return null;
  }

  @override
  Widget build(BuildContext context) {
    final FirebaseService dbService = FirebaseService();

    final subTextStyle = TextStyle(
      color: Theme.of(context).colorScheme.onSurface.withValues(alpha: 0.7),
      fontSize: 13,
    );

    return Scaffold(
      body: CustomScrollView(
        slivers: [
          SliverAppBar(
            expandedHeight: 260,
            pinned: true,
            flexibleSpace: FlexibleSpaceBar(
              title: Text(
                review.restaurantName,
                style: const TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                  shadows: [Shadow(blurRadius: 8, color: Colors.black)],
                ),
              ),
              background: Stack(
                fit: StackFit.expand,
                children: [
                  Hero(
                    tag: 'review-image-${review.id}',
                    child: AppImage(
                      imageUrl: review.imageUrl,
                      fit: BoxFit.cover,
                    ),
                  ),
                  const DecoratedBox(
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                        colors: [
                          Colors.transparent,
                          Colors.black87,
                        ],
                        stops: [0.5, 1.0],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
          SliverList(
            delegate: SliverChildListDelegate([
              Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Main Review Card Container
                    Card(
                      elevation: 3,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
                      child: Padding(
                        padding: const EdgeInsets.all(16.0),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            // Badges Row
                            Wrap(
                              spacing: 8,
                              runSpacing: 8,
                              alignment: WrapAlignment.spaceBetween,
                              crossAxisAlignment: WrapCrossAlignment.center,
                              children: [
                                Chip(
                                  avatar: const Icon(Icons.star_rounded, size: 18, color: Colors.amber),
                                  label: Text(
                                    '${review.rating.toStringAsFixed(1)} ★',
                                    style: const TextStyle(fontWeight: FontWeight.bold),
                                  ),
                                  backgroundColor: AppTheme.accentColor.withValues(alpha: 0.15),
                                ),
                                Chip(
                                  avatar: const Icon(Icons.restaurant_outlined, size: 16),
                                  label: Text(
                                    review.cuisine,
                                    style: const TextStyle(fontWeight: FontWeight.w600),
                                  ),
                                ),
                                Chip(
                                  avatar: const Icon(Icons.calendar_today_outlined, size: 16),
                                  label: Text(
                                    'Visited ${review.visitDate}',
                                    style: const TextStyle(fontSize: 12),
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(height: 12),

                            Text(
                              'Spot Details',
                              style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold),
                            ),
                            const SizedBox(height: 6),
                            Text(
                              review.reviewText,
                              style: const TextStyle(fontSize: 15, height: 1.4),
                            ),
                            const Divider(height: 24),

                            // Location & Author Info
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Row(
                                  children: [
                                    Icon(
                                      review.hasGpsTag ? Icons.location_on : Icons.location_off_outlined,
                                      size: 16,
                                      color: review.hasGpsTag ? AppTheme.secondaryColor : Colors.grey,
                                    ),
                                    const SizedBox(width: 6),
                                    Expanded(
                                      child: Text(
                                        review.hasGpsTag
                                            ? 'GPS Tagged: ${review.latitude.toStringAsFixed(3)}, ${review.longitude.toStringAsFixed(3)}'
                                            : 'GPS Location: Not Tagged',
                                        style: subTextStyle,
                                        overflow: TextOverflow.ellipsis,
                                      ),
                                    ),
                                  ],
                                ),
                                const SizedBox(height: 6),
                                Row(
                                  children: [
                                    const Icon(Icons.person_outline, size: 16, color: AppTheme.secondaryColor),
                                    const SizedBox(width: 6),
                                    Expanded(
                                      child: Text(
                                        'Posted by ${review.userEmail}',
                                        style: subTextStyle,
                                        overflow: TextOverflow.ellipsis,
                                      ),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(height: 24),

                    // Community Reviews Header & Add Button
                    Wrap(
                      spacing: 12,
                      runSpacing: 8,
                      alignment: WrapAlignment.spaceBetween,
                      crossAxisAlignment: WrapCrossAlignment.center,
                      children: [
                        Text(
                          'Community Reviews',
                          style: Theme.of(context).textTheme.titleLarge?.copyWith(
                                fontWeight: FontWeight.bold,
                              ),
                        ),
                        ElevatedButton.icon(
                          onPressed: () {
                            if (review.id == null) return;
                            showDialog(
                              context: context,
                              builder: (_) => AddResponseDialog(
                                reviewId: review.id!,
                                restaurantName: review.restaurantName,
                              ),
                            );
                          },
                          style: ElevatedButton.styleFrom(
                            backgroundColor: AppTheme.accentColor,
                            foregroundColor: AppTheme.darkOnButtonColor,
                            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                          ),
                          icon: const Icon(Icons.add_comment_rounded, size: 18, color: AppTheme.darkOnButtonColor),
                          label: const Text('Add Review & Photo', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 13, color: AppTheme.darkOnButtonColor)),
                        ),
                      ],
                    ),
                    const SizedBox(height: 12),

                    // Stream of User Responses
                    if (review.id != null)
                      StreamBuilder<List<UserResponseModel>>(
                        stream: dbService.getResponsesStream(review.id!),
                        builder: (context, snapshot) {
                          if (snapshot.connectionState == ConnectionState.waiting) {
                            return const Center(
                              child: Padding(
                                padding: EdgeInsets.all(24.0),
                                child: CircularProgressIndicator(),
                              ),
                            );
                          }

                          final responses = snapshot.data ?? [];

                          if (responses.isEmpty) {
                            return Container(
                              width: double.infinity,
                              padding: const EdgeInsets.all(20),
                              decoration: BoxDecoration(
                                color: Theme.of(context).colorScheme.surface,
                                borderRadius: BorderRadius.circular(16),
                                border: Border.all(
                                  color: Theme.of(context).colorScheme.onSurface.withValues(alpha: 0.1),
                                ),
                              ),
                              child: Column(
                                children: [
                                  Icon(
                                    Icons.rate_review_outlined,
                                    size: 40,
                                    color: AppTheme.secondaryColor.withValues(alpha: 0.5),
                                  ),
                                  const SizedBox(height: 8),
                                  Text(
                                    'No community reviews for this spot yet.',
                                    style: TextStyle(
                                      color: Theme.of(context).colorScheme.onSurface.withValues(alpha: 0.7),
                                      fontWeight: FontWeight.w500,
                                    ),
                                  ),
                                  const SizedBox(height: 4),
                                  const Text(
                                    'Be the first to share your rating & dish photo!',
                                    style: TextStyle(fontSize: 12, color: AppTheme.secondaryColor),
                                  ),
                                ],
                              ),
                            );
                          }

                          return ListView.builder(
                            shrinkWrap: true,
                            physics: const NeverScrollableScrollPhysics(),
                            itemCount: responses.length,
                            itemBuilder: (context, index) {
                              final item = responses[index];
                              final user = FirebaseAuth.instance.currentUser;
                              final currentUserId = user?.uid;
                              final currentUserEmail = user?.email?.toLowerCase().trim();
                              final currentDisplayName = user?.displayName?.toLowerCase().trim();

                              final isResponseOwner = (currentUserId != null && currentUserId == item.userId) ||
                                  (currentUserEmail != null &&
                                      currentUserEmail.isNotEmpty &&
                                      item.userEmail.toLowerCase().trim() == currentUserEmail) ||
                                  (currentDisplayName != null &&
                                      currentDisplayName.isNotEmpty &&
                                      (item.userName.toLowerCase().contains(currentDisplayName) ||
                                       item.userEmail.toLowerCase().contains(currentDisplayName)));

                              return Card(
                                margin: const EdgeInsets.only(bottom: 16),
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(16),
                                ),
                                child: Padding(
                                  padding: const EdgeInsets.all(14.0),
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      // User Avatar & Name Row
                                      Row(
                                        children: [
                                          CircleAvatar(
                                            radius: 18,
                                            backgroundColor: AppTheme.secondaryColor,
                                            backgroundImage: _getUserAvatar(item.userPhotoUrl),
                                            child: item.userPhotoUrl.isEmpty
                                                ? const Icon(Icons.person, size: 20, color: Colors.white)
                                                : null,
                                          ),
                                          const SizedBox(width: 10),
                                          Expanded(
                                            child: Column(
                                              crossAxisAlignment: CrossAxisAlignment.start,
                                              children: [
                                                Text(
                                                  item.userName,
                                                  style: const TextStyle(
                                                    fontWeight: FontWeight.bold,
                                                    fontSize: 14,
                                                  ),
                                                  maxLines: 1,
                                                  overflow: TextOverflow.ellipsis,
                                                ),
                                                Text(
                                                  'Visited on ${item.date}',
                                                  style: TextStyle(
                                                    fontSize: 11,
                                                    color: Theme.of(context).colorScheme.onSurface.withValues(alpha: 0.6),
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                          Container(
                                            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                                            decoration: BoxDecoration(
                                              color: Colors.amber.shade100,
                                              borderRadius: BorderRadius.circular(12),
                                            ),
                                            child: Row(
                                              children: [
                                                const Icon(Icons.star_rounded, size: 14, color: Colors.amber),
                                                const SizedBox(width: 2),
                                                Text(
                                                  item.rating.toStringAsFixed(1),
                                                  style: const TextStyle(
                                                    fontWeight: FontWeight.bold,
                                                    fontSize: 12,
                                                    color: Colors.black87,
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                          if (isResponseOwner)
                                            IconButton(
                                              icon: const Icon(Icons.delete_outline, size: 18, color: Colors.redAccent),
                                              onPressed: () {
                                                if (item.id != null) {
                                                  dbService.deleteResponse(item.id!, item.imageUrl);
                                                }
                                              },
                                            ),
                                        ],
                                      ),
                                      const SizedBox(height: 10),

                                      // Review Comment Text
                                      Text(
                                        item.comment,
                                        style: const TextStyle(fontSize: 14, height: 1.3),
                                      ),

                                      // User's Attached Dish Photo
                                      if (item.imageUrl.isNotEmpty) ...[
                                        const SizedBox(height: 10),
                                        ClipRRect(
                                          borderRadius: BorderRadius.circular(12),
                                          child: AppImage(
                                            imageUrl: item.imageUrl,
                                            height: 180,
                                            width: double.infinity,
                                            fit: BoxFit.cover,
                                          ),
                                        ),
                                      ],
                                    ],
                                  ),
                                ),
                              );
                            },
                          );
                        },
                      ),
                  ],
                ),
              ),
            ]),
          )
        ],
      ),
    );
  }
}
