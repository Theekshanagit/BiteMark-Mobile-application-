import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../services/auth_service.dart';
import '../services/firebase_service.dart';
import '../services/image_service.dart';
import '../services/storage_service.dart';
import '../models/review_model.dart';
import '../widgets/review_form_dialog.dart';
import '../widgets/app_image.dart';
import 'detail_screen.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  final AuthService _authService = AuthService();
  final FirebaseService _dbService = FirebaseService();
  final ImageService _imageService = ImageService();
  final StorageService _storageService = StorageService();

  ImageProvider? _getProfileImage(String? photoUrl) {
    if (photoUrl == null || photoUrl.trim().isEmpty) return null;
    final trimmed = photoUrl.trim();

    if (trimmed.startsWith('data:image/')) {
      try {
        final commaIndex = trimmed.indexOf(',');
        if (commaIndex != -1) {
          return MemoryImage(base64Decode(trimmed.substring(commaIndex + 1)));
        }
      } catch (_) {}
    }

    if (trimmed.startsWith('http://') || trimmed.startsWith('https://')) {
      return NetworkImage(trimmed);
    }

    final file = File(trimmed);
    if (file.existsSync()) {
      return FileImage(file);
    }
    return null;
  }

  Future<void> _updatePhoto(String photoUrl) async {
    final messenger = ScaffoldMessenger.of(context);
    try {
      await _authService.updateProfilePhoto(photoUrl);
      if (mounted) {
        setState(() {});
        messenger.showSnackBar(
          const SnackBar(
            content: Text('Profile picture updated!'),
            backgroundColor: Colors.green,
          ),
        );
      }
    } catch (e) {
      if (mounted) {
        messenger.showSnackBar(
          SnackBar(
            content: Text('Failed to update picture: $e'),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

  void _showError(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(msg), backgroundColor: Colors.red),
    );
  }

  Future<void> _showPhotoPickerOptions(BuildContext context) async {
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (ctx) {
        return SafeArea(
          child: Wrap(
            children: [
              ListTile(
                leading: const Icon(Icons.camera_alt, color: Colors.deepOrange),
                title: const Text('Take Photo (Camera)'),
                onTap: () async {
                  Navigator.pop(ctx);
                  final file = await _imageService.capturePhoto();
                  if (file != null) {
                    try {
                      final downloadUrl = await _storageService.uploadImage(file, folder: 'profiles');
                      await _updatePhoto(downloadUrl);
                    } catch (e) {
                      _showError(e.toString().replaceAll('Exception: ', ''));
                    }
                  }
                },
              ),
              ListTile(
                leading: const Icon(Icons.photo_library, color: Colors.deepOrange),
                title: const Text('Choose from Gallery'),
                onTap: () async {
                  Navigator.pop(ctx);
                  final file = await _imageService.pickFromGallery();
                  if (file != null) {
                    try {
                      final downloadUrl = await _storageService.uploadImage(file, folder: 'profiles');
                      await _updatePhoto(downloadUrl);
                    } catch (e) {
                      _showError(e.toString().replaceAll('Exception: ', ''));
                    }
                  }
                },
              ),
              ListTile(
                leading: const Icon(Icons.link, color: Colors.deepOrange),
                title: const Text('Enter Image URL'),
                onTap: () {
                  Navigator.pop(ctx);
                  _showImageUrlDialog(context);
                },
              ),
            ],
          ),
        );
      },
    );
  }

  Future<void> _showImageUrlDialog(BuildContext context) async {
    final user = FirebaseAuth.instance.currentUser;
    final controller = TextEditingController(text: user?.photoURL ?? '');
    final formKey = GlobalKey<FormState>();

    return showDialog(
      context: context,
      builder: (ctx) {
        return AlertDialog(
          title: const Text('Profile Photo URL'),
          content: Form(
            key: formKey,
            child: TextFormField(
              controller: controller,
              decoration: const InputDecoration(
                labelText: 'Image URL',
                hintText: 'https://example.com/photo.jpg',
                border: OutlineInputBorder(),
              ),
              validator: (val) {
                if (val == null || val.trim().isEmpty) {
                  return 'Please enter an image URL';
                }
                return null;
              },
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(ctx),
              child: const Text('Cancel'),
            ),
            ElevatedButton(
              onPressed: () async {
                if (!formKey.currentState!.validate()) return;
                final url = controller.text.trim();
                Navigator.pop(ctx);
                await _updatePhoto(url);
              },
              child: const Text('Save'),
            ),
          ],
        );
      },
    );
  }

  Future<void> _showEditUsernameDialog(BuildContext context, User? user) async {
    final controller = TextEditingController(text: user?.displayName ?? '');
    final formKey = GlobalKey<FormState>();

    return showDialog(
      context: context,
      builder: (ctx) {
        return AlertDialog(
          title: const Text('Edit Username'),
          content: Form(
            key: formKey,
            child: TextFormField(
              controller: controller,
              decoration: const InputDecoration(
                labelText: 'Username',
                hintText: 'Enter your username',
                border: OutlineInputBorder(),
              ),
              validator: (val) {
                if (val == null || val.trim().isEmpty) {
                  return 'Username cannot be empty';
                }
                return null;
              },
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(ctx),
              child: const Text('Cancel'),
            ),
            ElevatedButton(
              onPressed: () async {
                if (!formKey.currentState!.validate()) return;
                final newUsername = controller.text.trim();
                final messenger = ScaffoldMessenger.of(context);
                Navigator.pop(ctx);
                try {
                  await _authService.updateUsername(newUsername);
                  if (mounted) {
                    setState(() {});
                    messenger.showSnackBar(
                      const SnackBar(
                        content: Text('Username updated successfully!'),
                        backgroundColor: Colors.green,
                      ),
                    );
                  }
                } catch (e) {
                  if (mounted) {
                    messenger.showSnackBar(
                      SnackBar(
                        content: Text('Failed to update username: $e'),
                        backgroundColor: Colors.red,
                      ),
                    );
                  }
                }
              },
              child: const Text('Save'),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final user = FirebaseAuth.instance.currentUser;

    return Scaffold(
      appBar: AppBar(
        title: const Text('My Profile'),
        actions: [
          IconButton(
            icon: const Icon(Icons.logout, color: Colors.red),
            onPressed: () async => await _authService.signOut(),
          ),
        ],
      ),
      body: Column(
        children: [
          const SizedBox(height: 20),
          Stack(
            children: [
              GestureDetector(
                onTap: () => _showPhotoPickerOptions(context),
                child: CircleAvatar(
                  radius: 48,
                  backgroundColor: Colors.deepOrange,
                  backgroundImage: _getProfileImage(user?.photoURL),
                  child: (_getProfileImage(user?.photoURL) == null)
                      ? const Icon(Icons.person, size: 55, color: Colors.white)
                      : null,
                ),
              ),
              Positioned(
                bottom: 0,
                right: 0,
                child: GestureDetector(
                  onTap: () => _showPhotoPickerOptions(context),
                  child: Container(
                    padding: const EdgeInsets.all(6),
                    decoration: BoxDecoration(
                      color: Colors.deepOrange,
                      shape: BoxShape.circle,
                      border: Border.all(color: Colors.white, width: 2),
                    ),
                    child: const Icon(Icons.camera_alt, size: 16, color: Colors.white),
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                (user?.displayName != null && user!.displayName!.isNotEmpty)
                    ? user.displayName!
                    : 'Add Username',
                style: Theme.of(context).textTheme.titleLarge?.copyWith(
                      fontWeight: FontWeight.bold,
                    ),
              ),
              IconButton(
                icon: const Icon(Icons.edit, size: 20, color: Colors.deepOrange),
                tooltip: 'Edit Username',
                onPressed: () => _showEditUsernameDialog(context, user),
              ),
            ],
          ),
          Text(
            user?.email ?? 'User Email',
            style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                  color: Theme.of(context).colorScheme.onSurface.withValues(alpha: 0.7),
                ),
          ),
          const Divider(height: 24),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16.0),
            child: Align(
              alignment: Alignment.centerLeft,
              child: Text(
                'My Submitted Reviews',
                style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold),
              ),
            ),
          ),
          Expanded(
            child: StreamBuilder<List<ReviewModel>>(
              stream: _dbService.getReviewsStream(),
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return const Center(child: CircularProgressIndicator());
                }

                final myUserId = user?.uid;
                final myEmail = user?.email?.toLowerCase().trim();
                final myName = user?.displayName?.toLowerCase().trim();

                final myReviews = (snapshot.data ?? []).where((r) {
                  if (myUserId != null && r.userId == myUserId) return true;
                  if (myEmail != null && myEmail.isNotEmpty && r.userEmail.toLowerCase().trim() == myEmail) return true;
                  if (myName != null && myName.isNotEmpty && (r.userEmail.toLowerCase().contains(myName) || r.userId.toLowerCase().contains(myName))) return true;
                  return false;
                }).toList();

                if (myReviews.isEmpty) {
                  return const Center(child: Text('You have not submitted any reviews yet.'));
                }

                return ListView.builder(
                  itemCount: myReviews.length,
                  itemBuilder: (context, index) {
                    final review = myReviews[index];
                    return ListTile(
                      leading: SizedBox(
                        width: 50,
                        height: 50,
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(8),
                          child: AppImage(
                            imageUrl: review.imageUrl,
                            width: 50,
                            height: 50,
                            fit: BoxFit.cover,
                          ),
                        ),
                      ),
                      title: Text(review.restaurantName),
                      subtitle: Text('${review.rating} ★ • ${review.visitDate}'),
                      trailing: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          IconButton(
                            icon: const Icon(Icons.edit, color: Colors.deepOrange),
                            onPressed: () {
                              showDialog(
                                context: context,
                                builder: (_) => ReviewFormDialog(existingReview: review),
                              );
                            },
                          ),
                          IconButton(
                            icon: const Icon(Icons.delete, color: Colors.red),
                            onPressed: () => _dbService.deleteReview(review),
                          ),
                        ],
                      ),
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => DetailScreen(review: review),
                          ),
                        );
                      },
                    );
                  },
                );
              },
            ),
          )
        ],
      ),
    );
  }
}
