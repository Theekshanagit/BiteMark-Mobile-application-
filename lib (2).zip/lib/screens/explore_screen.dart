import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import '../models/review_model.dart';
import '../services/firebase_service.dart';
import '../services/location_service.dart';
import '../widgets/app_image.dart';
import '../widgets/custom_page_route.dart';
import 'detail_screen.dart';

class ExploreScreen extends StatefulWidget {
  const ExploreScreen({super.key});

  @override
  State<ExploreScreen> createState() => _ExploreScreenState();
}

class _ExploreScreenState extends State<ExploreScreen> {
  final FirebaseService _dbService = FirebaseService();
  final LocationService _locationService = LocationService();

  String _selectedCategory = 'All';
  Position? _currentPosition;

  final List<String> _categories = [
    'All',
    'Italian',
    'Mexican',
    'Japanese',
    'American',
    'Indian',
    'Vegan',
  ];

  @override
  void initState() {
    super.initState();
    _getUserLocation();
  }

  Future<void> _getUserLocation() async {
    try {
      final pos = await _locationService.getCurrentLocation();
      if (mounted && pos != null) {
        setState(() => _currentPosition = pos);
      }
    } catch (_) {}
  }

  double? _calculateDistanceInKm(ReviewModel item) {
    if (!item.hasGpsTag || _currentPosition == null) return null;
    if (item.latitude == 0.0 && item.longitude == 0.0) return null;
    try {
      final meters = Geolocator.distanceBetween(
        _currentPosition!.latitude,
        _currentPosition!.longitude,
        item.latitude,
        item.longitude,
      );
      return meters / 1000.0;
    } catch (_) {
      return null;
    }
  }

  @override
  Widget build(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width;
    final int crossAxisCount = screenWidth > 900 ? 4 : (screenWidth > 600 ? 3 : 2);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Explore Nearby'),
        actions: [
          IconButton(
            icon: const Icon(Icons.my_location),
            tooltip: 'Refresh Location',
            onPressed: _getUserLocation,
          ),
        ],
      ),
      body: Column(
        children: [
          // Filter Chips
          SizedBox(
            height: 60,
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
              itemCount: _categories.length,
              itemBuilder: (context, index) {
                final category = _categories[index];
                return Padding(
                  padding: const EdgeInsets.only(right: 8),
                  child: ChoiceChip(
                    label: Text(category),
                    selected: _selectedCategory == category,
                    onSelected: (selected) {
                      if (selected) setState(() => _selectedCategory = category);
                    },
                  ),
                );
              },
            ),
          ),
          Expanded(
            child: StreamBuilder<List<ReviewModel>>(
              stream: _dbService.getReviewsStream(),
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return const Center(child: CircularProgressIndicator());
                }

                final allReviews = snapshot.data ?? [];
                var filteredReviews = _selectedCategory == 'All'
                    ? allReviews
                    : allReviews.where((r) => r.cuisine == _selectedCategory).toList();

                // Sort by Proximity if location is available
                if (_currentPosition != null) {
                  filteredReviews.sort((a, b) {
                    final distA = _calculateDistanceInKm(a) ?? double.infinity;
                    final distB = _calculateDistanceInKm(b) ?? double.infinity;
                    return distA.compareTo(distB);
                  });
                }

                if (filteredReviews.isEmpty) {
                  return Center(
                    child: Text('No reviews found for $_selectedCategory.'),
                  );
                }

                return GridView.builder(
                  padding: const EdgeInsets.all(12),
                  gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: crossAxisCount,
                    childAspectRatio: 0.72,
                    crossAxisSpacing: 12,
                    mainAxisSpacing: 12,
                  ),
                  itemCount: filteredReviews.length,
                  itemBuilder: (context, index) {
                    final item = filteredReviews[index];
                    final distanceKm = _calculateDistanceInKm(item);

                    return Card(
                      clipBehavior: Clip.antiAlias,
                      child: InkWell(
                        onTap: () {
                          Navigator.push(
                            context,
                            CustomPageRoute(child: DetailScreen(review: item)),
                          );
                        },
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Expanded(
                              child: AppImage(
                                imageUrl: item.imageUrl,
                                width: double.infinity,
                                fit: BoxFit.cover,
                              ),
                            ),
                            Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    item.restaurantName,
                                    style: const TextStyle(fontWeight: FontWeight.bold),
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                  Row(
                                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                    children: [
                                      Text(
                                        '${item.rating} ★ • ${item.cuisine}',
                                        style: TextStyle(
                                          color: Theme.of(context).colorScheme.onSurface.withValues(alpha: 0.7),
                                          fontSize: 12,
                                        ),
                                      ),
                                      if (distanceKm != null)
                                        Text(
                                          '${distanceKm.toStringAsFixed(1)} km',
                                          style: const TextStyle(
                                            color: Colors.deepOrange,
                                            fontWeight: FontWeight.bold,
                                            fontSize: 11,
                                          ),
                                        ),
                                    ],
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
