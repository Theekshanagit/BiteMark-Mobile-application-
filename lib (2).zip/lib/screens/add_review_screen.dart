import 'dart:io';
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:geolocator/geolocator.dart';
import '../models/review_model.dart';
import '../services/firebase_service.dart';
import '../services/location_service.dart';
import '../services/image_service.dart';
import '../services/storage_service.dart';
import '../widgets/app_image.dart';

class AddReviewScreen extends StatefulWidget {
  const AddReviewScreen({super.key});

  @override
  State<AddReviewScreen> createState() => _AddReviewScreenState();
}

class _AddReviewScreenState extends State<AddReviewScreen> {
  final _formKey = GlobalKey<FormState>();
  final FirebaseService _dbService = FirebaseService();
  final LocationService _locationService = LocationService();
  final ImageService _imageService = ImageService();
  final StorageService _storageService = StorageService();

  final _nameController = TextEditingController();
  final _reviewController = TextEditingController();

  String _selectedCuisine = 'Italian';
  double _rating = 4.0;
  DateTime _selectedDate = DateTime.now();
  bool _isLoading = false;
  bool _isFetchingLocation = false;

  double? _latitude;
  double? _longitude;
  bool _hasGpsTag = false;
  String _selectedImagePath = '';

  final List<String> _cuisines = [
    'Italian',
    'Mexican',
    'Japanese',
    'American',
    'Indian',
    'Vegan',
  ];

  @override
  void dispose() {
    _nameController.dispose();
    _reviewController.dispose();
    super.dispose();
  }

  Future<void> _takePicture() async {
    try {
      final File? image = await _imageService.capturePhoto();
      if (image != null) {
        setState(() => _selectedImagePath = image.path);
      }
    } catch (e) {
      _showError('Camera Error: $e');
    }
  }

  Future<void> _pickFromGallery() async {
    try {
      final File? image = await _imageService.pickFromGallery();
      if (image != null) {
        setState(() => _selectedImagePath = image.path);
      }
    } catch (e) {
      _showError('Gallery Error: $e');
    }
  }

  Future<void> _fetchGPSLocation() async {
    setState(() => _isFetchingLocation = true);
    try {
      final Position? pos = await _locationService.getCurrentLocation();
      if (pos != null) {
        setState(() {
          _latitude = pos.latitude;
          _longitude = pos.longitude;
          _hasGpsTag = true;
        });
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text('GPS Location tagged successfully!'),
              backgroundColor: Colors.green,
            ),
          );
        }
      }
    } catch (e) {
      _showError(e.toString().replaceAll('Exception: ', ''));
    } finally {
      if (mounted) setState(() => _isFetchingLocation = false);
    }
  }

  Future<void> _selectVisitDate(BuildContext context) async {
    final picked = await showDatePicker(
      context: context,
      initialDate: _selectedDate,
      firstDate: DateTime(2000),
      lastDate: DateTime.now(),
    );
    if (picked != null) {
      setState(() => _selectedDate = picked);
    }
  }

  void _showError(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(msg), backgroundColor: Colors.red),
    );
  }

  Future<void> _submitForm() async {
    if (!_formKey.currentState!.validate()) return;

    final user = FirebaseAuth.instance.currentUser;
    if (user == null) {
      _showError('Please sign in to post a review.');
      return;
    }

    setState(() => _isLoading = true);

    try {
      String imageUrl = _selectedImagePath.trim();
      if (imageUrl.isNotEmpty && !imageUrl.startsWith('http') && !imageUrl.startsWith('data:')) {
        imageUrl = await _storageService.uploadImage(File(imageUrl), folder: 'reviews');
      }

      final newReview = ReviewModel(
        userId: user.uid,
        userEmail: user.email ?? 'anonymous@bitemark.com',
        restaurantName: _nameController.text.trim(),
        cuisine: _selectedCuisine,
        rating: _rating,
        reviewText: _reviewController.text.trim(),
        imageUrl: imageUrl,
        visitDate: _selectedDate.toIso8601String().split('T')[0],
        latitude: _latitude ?? 0.0,
        longitude: _longitude ?? 0.0,
        hasGpsTag: _hasGpsTag,
      );

      await _dbService.createReview(newReview);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Review posted successfully!'),
            backgroundColor: Colors.green,
          ),
        );
        _nameController.clear();
        _reviewController.clear();
        setState(() {
          _rating = 4.0;
          _selectedCuisine = 'Italian';
          _selectedDate = DateTime.now();
          _selectedImagePath = '';
          _latitude = null;
          _longitude = null;
          _hasGpsTag = false;
        });
      }
    } catch (e) {
      _showError('Error saving review: $e');
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Post New Review')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20.0),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              TextFormField(
                controller: _nameController,
                decoration: const InputDecoration(
                  labelText: 'Restaurant Name',
                  border: OutlineInputBorder(),
                ),
                validator: (val) => val == null || val.trim().isEmpty
                    ? 'Please enter a restaurant name'
                    : null,
              ),
              const SizedBox(height: 16),

              DropdownButtonFormField<String>(
                initialValue: _selectedCuisine,
                decoration: const InputDecoration(
                  labelText: 'Cuisine',
                  border: OutlineInputBorder(),
                ),
                items: _cuisines
                    .map((c) => DropdownMenuItem(value: c, child: Text(c)))
                    .toList(),
                onChanged: (val) => setState(() => _selectedCuisine = val!),
              ),
              const SizedBox(height: 16),

              // Visit Date Picker
              InkWell(
                onTap: () => _selectVisitDate(context),
                child: InputDecorator(
                  decoration: const InputDecoration(
                    labelText: 'Visit Date',
                    prefixIcon: Icon(Icons.calendar_today_outlined),
                    border: OutlineInputBorder(),
                  ),
                  child: Text(
                    '${_selectedDate.year}-${_selectedDate.month.toString().padLeft(2, '0')}-${_selectedDate.day.toString().padLeft(2, '0')}',
                  ),
                ),
              ),
              const SizedBox(height: 16),

              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Rating: ${_rating.toStringAsFixed(1)} ★',
                    style: const TextStyle(fontWeight: FontWeight.bold),
                  ),
                  Slider(
                    value: _rating,
                    min: 1.0,
                    max: 5.0,
                    divisions: 8,
                    label: _rating.toString(),
                    onChanged: (val) => setState(() => _rating = val),
                  ),
                ],
              ),

              TextFormField(
                controller: _reviewController,
                maxLines: 3,
                decoration: const InputDecoration(
                  labelText: 'Review Comments',
                  border: OutlineInputBorder(),
                ),
                validator: (val) => val == null || val.trim().isEmpty
                    ? 'Please write a review comment'
                    : null,
              ),
              const SizedBox(height: 16),

              // Food Photo Box
              const Text(
                'Food Dish Photo',
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 13),
              ),
              const SizedBox(height: 6),
              ClipRRect(
                borderRadius: BorderRadius.circular(12),
                child: AppImage(
                  imageUrl: _selectedImagePath,
                  height: 160,
                  width: double.infinity,
                  fit: BoxFit.cover,
                ),
              ),
              const SizedBox(height: 8),

              Row(
                children: [
                  Expanded(
                    child: OutlinedButton.icon(
                      onPressed: _takePicture,
                      icon: const Icon(Icons.camera_alt, size: 18),
                      label: const Text('Camera'),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: OutlinedButton.icon(
                      onPressed: _pickFromGallery,
                      icon: const Icon(Icons.photo_library, size: 18),
                      label: const Text('Gallery'),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 16),

              // GPS Button
              ElevatedButton.icon(
                onPressed: _isFetchingLocation ? null : _fetchGPSLocation,
                style: ElevatedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(vertical: 12),
                ),
                icon: _isFetchingLocation
                    ? const SizedBox(
                        height: 16,
                        width: 16,
                        child: CircularProgressIndicator(strokeWidth: 2),
                      )
                    : const Icon(Icons.my_location),
                label: Text(
                  _latitude != null
                      ? 'GPS: ${_latitude!.toStringAsFixed(3)}, ${_longitude!.toStringAsFixed(3)}'
                      : 'Tag Current Location (GPS)',
                ),
              ),
              const SizedBox(height: 24),

              ElevatedButton(
                onPressed: _isLoading ? null : _submitForm,
                style: ElevatedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(vertical: 16),
                  backgroundColor: Theme.of(context).primaryColor,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
                child: _isLoading
                    ? const SizedBox(
                        height: 20,
                        width: 20,
                        child: CircularProgressIndicator(
                          strokeWidth: 2,
                          color: Colors.white,
                        ),
                      )
                    : const Text(
                        'Post Review',
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                          color: Colors.white,
                        ),
                      ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
