class UserResponseModel {
  final String? id;
  final String reviewId;
  final String userId;
  final String userEmail;
  final String userName;
  final String userPhotoUrl;
  final double rating;
  final String comment;
  final String imageUrl;
  final String date;

  UserResponseModel({
    this.id,
    required this.reviewId,
    required this.userId,
    required this.userEmail,
    required this.userName,
    required this.userPhotoUrl,
    required this.rating,
    required this.comment,
    required this.imageUrl,
    required this.date,
  });

  factory UserResponseModel.fromMap(String key, Map<dynamic, dynamic> map) {
    return UserResponseModel(
      id: key,
      reviewId: map['reviewId'] ?? '',
      userId: map['userId'] ?? '',
      userEmail: map['userEmail'] ?? '',
      userName: map['userName'] ?? '',
      userPhotoUrl: map['userPhotoUrl'] ?? '',
      rating: (map['rating'] as num?)?.toDouble() ?? 0.0,
      comment: map['comment'] ?? '',
      imageUrl: map['imageUrl'] ?? '',
      date: map['date'] ?? '',
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'reviewId': reviewId,
      'userId': userId,
      'userEmail': userEmail,
      'userName': userName,
      'userPhotoUrl': userPhotoUrl,
      'rating': rating,
      'comment': comment,
      'imageUrl': imageUrl,
      'date': date,
    };
  }
}
