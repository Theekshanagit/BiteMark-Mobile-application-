class ReviewModel {
  final String? id;
  final String userId;
  final String userEmail;
  final String restaurantName;
  final String cuisine;
  final double rating;
  final String reviewText;
  final String imageUrl;
  final String visitDate;
  final double latitude;
  final double longitude;
  final bool hasGpsTag;

  ReviewModel({
    this.id,
    required this.userId,
    required this.userEmail,
    required this.restaurantName,
    required this.cuisine,
    required this.rating,
    required this.reviewText,
    required this.imageUrl,
    required this.visitDate,
    required this.latitude,
    required this.longitude,
    this.hasGpsTag = false,
  });

  // Convert Firebase JSON map into ReviewModel instance
  factory ReviewModel.fromMap(String key, Map<dynamic, dynamic> map) {
    return ReviewModel(
      id: key,
      userId: map['userId'] ?? '',
      userEmail: map['userEmail'] ?? '',
      restaurantName: map['restaurantName'] ?? '',
      cuisine: map['cuisine'] ?? '',
      rating: (map['rating'] as num?)?.toDouble() ?? 0.0,
      reviewText: map['reviewText'] ?? '',
      imageUrl: map['imageUrl'] ?? '',
      visitDate: map['visitDate'] ?? '',
      latitude: (map['latitude'] as num?)?.toDouble() ?? 0.0,
      longitude: (map['longitude'] as num?)?.toDouble() ?? 0.0,
      hasGpsTag: map['hasGpsTag'] == true,
    );
  }

  // Convert ReviewModel to Map for Firebase writing
  Map<String, dynamic> toMap() {
    return {
      'userId': userId,
      'userEmail': userEmail,
      'restaurantName': restaurantName,
      'cuisine': cuisine,
      'rating': rating,
      'reviewText': reviewText,
      'imageUrl': imageUrl,
      'visitDate': visitDate,
      'latitude': latitude,
      'longitude': longitude,
      'hasGpsTag': hasGpsTag,
    };
  }
}
